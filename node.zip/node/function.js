var  array = require("array");
const  express = require("express");
var  fs = require("fs");
var datagrid = require("./js/datagrid.js");
var render = require("./js/render.js");
var parser = require("./js/parser.js");
const app = express();
const THEME = "Themes";
var theme = "style";

function Load() {

var batches = __dirname + "/" + THEME + "/" + theme;
	try {
		fs.readFile(batches.replace("\js","").replace("\\","\/"), null, function(err, contents) {
		if(contents != null) {
			style = contents.toString();
			styled = contents.toString();
		}});
		
	}
	catch(Exception ) {     }
	finally {  }

}

function batch() {
var theme = __dirname + "/" + THEME + "/" + "batch";

	try {
		fs.readFile(theme.replace("\js","").replace("\\","\/"), null, function(err, contents) {
		run(contents.toString()); 
		});
	}
	catch(Exception ) {     }
	finally { /*console.log(":" + fns);*/  }
}

var style = "";
var styled = "";
var clrs = "";
var sclr = "";

function stylen(len) {
sclr = parser();

var w = "";
var h = ""; 
var bk = "";
for(i=0; i<clrs.split(' ').length;i++) {
	
	if(clrs.split(' ')[i].indexOf('width') >= 0 && w == "") {
		w = clrs.split(' ')[i];
	}else if(clrs.split(' ')[i].indexOf('height') >= 0 && h == "") {
		h = clrs.split(' ')[i];
}else if(clrs.split(' ')[i].indexOf('background-color') >= 0 && bk == "") { bk = clrs.split(' ')[i] + ' ' + clrs.split(' ')[i+1];}
}

var a = style.indexOf("pattern:");
var b = style.length;
if(b > 10) {
var cs = style.split("+ a +");
var pattern = style.substr(a,b);
clr = pattern.replace("pattern:", "");//substr(pattern.indexOf("0x")+2,6);
style = "";

	for(var a = 0; a < len; a++) 
	{
		style += cs[0].trim() + a + cs[1].replace('clr1',bk.split(':')[1].split(' ')[0]).replace('clr2',bk.split(':')[1].split(' ')[1]).replace("pattern:", "#para" + a);
	}
}	
	return ""/*"<style> " + style + " </style>"*/;
}			

function LOAD(THEME) {
	theme = THEME.split('/')[THEME.split('/').length - 1];
	wait(restyle,100);
	loadfile();
}

function restyle() {
var	sty = __dirname + "/" + THEME + "/" + theme;	
	try {
		fs.readFile(sty.replace("\js","").replace("\\","\/"), null, function(err, contents) {
		style = contents.toString(); });
	}
	catch(Exception ) {     }
	finally {   }
}

function script(clrs) {
	return clrs;
}

function redirect(res) {
	var test = datagrid.query();
	if(test != null) {
	var html = "<html><head>scriptstyle</head><body onload='load()'><div class='para'>para</div>content</body></html>";
	html = html.replace("style", stylen(test.length));
	html = html.replace("script", script(sclr));

	res.send(html.replace("content",mapele(test)));
	} else res.redirect("http://localhost:8080/");
}

var clr = "0000xx";
function mapele(data) {
var b = "";

var t = "<table style = 'display: block;' class='rotate' >content</table>";
	try{ var d = "<tr>";

		data.each(function(val,i){ 

		var myString = i.toString();
		var foo = parseInt(myString);
		d = "<td class = 'para' id = 'demo'>" + render(val,i,'red') + "</td>";


		if((i+1) % 4 == 0)
     			d = d + "</tr><tr>";  
     			b += d;
		});
	}catch(Exception ) {   } finally {   }
	b += "</tr>"; b = b.replace("<tr></tr>", ""); d = "<tr>";
     return t.replace("content",b);
}

function wait(fn,ms){
	var start = new Date().getTime();
	var end = start;
	fn();
	while(end < start + ms) {
		end = new Date().getTime();
	}
}

function run(fns) {
	wait(Load,100);	
	var funs = fns.split("\n");
	for(var i = 0; i < funs.length; i++) {
	try {
	switch(funs[i].split(':')[0].trim()) {
		
		case 'data':  wait(datagrid.datagrid,100); break;
		case 'style': LOAD(funs[i].split(':')[1].trim()); break;
		case 'parser': LOAD_PARSER(funs[i].split(':')[1].trim()); break;
		default: break;
	}
	}catch(Exception) { }
	finally {  }
	}
}

app.get('/', function (req,res){
	wait(batch,100);
	redirect(res);
});


var PORT = process.env.PORT || 8080;
app.listen(PORT, () => {   console.log("server running.. ")});